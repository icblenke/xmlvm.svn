#import "xmlvm.h"
#import "java_lang_Object.h"



// NSHTTPURLResponseHolder
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_NSHTTPURLResponseHolder : java_lang_Object
- (void) __init_org_xmlvm_iphone_NSHTTPURLResponseHolder;
@end

