#import "org_xmlvm_iphone_UIAlertViewDelegate.h"


// UIAlertViewDelegate
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_UIAlertViewDelegate

- (void) __init_org_xmlvm_iphone_UIAlertViewDelegate
{
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[self clickedButtonAtIndex___org_xmlvm_iphone_UIAlertView_int :alertView :buttonIndex];
}

- (void) clickedButtonAtIndex___org_xmlvm_iphone_UIAlertView_int
            :(org_xmlvm_iphone_UIAlertView*) alertView
            :(int) buttonIndex
{
}

@end

