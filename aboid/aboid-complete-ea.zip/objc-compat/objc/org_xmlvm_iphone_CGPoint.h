#import "xmlvm.h"
#import "java_lang_Object.h"
// CGPoint
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_CGPoint : java_lang_Object {
@public float x;
@public float y;
}
@end