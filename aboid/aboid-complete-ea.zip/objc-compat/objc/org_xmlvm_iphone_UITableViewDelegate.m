#import "org_xmlvm_iphone_UITableViewDelegate.h"


// UITableViewDelegate
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_UITableViewDelegate

- (void) __init_org_xmlvm_iphone_UITableViewDelegate
{
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
	return [self heightForRowAtIndexPath___org_xmlvm_iphone_UITableView_org_xmlvm_iphone_NSIndexPath :tableView :indexPath];
}

- (float) heightForRowAtIndexPath___org_xmlvm_iphone_UITableView_org_xmlvm_iphone_NSIndexPath :(UITableView*) tableView :(NSIndexPath*) indexPath
{
}


@end

