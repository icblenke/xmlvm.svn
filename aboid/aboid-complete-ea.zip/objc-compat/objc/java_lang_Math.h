#import "xmlvm.h"
#import "java_lang_Object.h"

// java.lang.Math
//----------------------------------------------------------------------------
@interface java_lang_Math : java_lang_Object

+ (double) random;
+ (double) sqrt___double: (double) x;
+ (double) asin___double: (double) x;
+ (int) abs___int: (int) i;
+ (float) abs___float: (float) f;
+ (float) max___float_float :(float) x :(float) y;
@end

