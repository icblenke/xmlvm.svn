#import "xmlvm.h"
#import "java_lang_Object.h"


@class org_xmlvm_iphone_UIControl;


// UIControlDelegate
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_UIControlDelegate : java_lang_Object
- (id) init;
- (void) __init_org_xmlvm_iphone_UIControlDelegate;
@end
