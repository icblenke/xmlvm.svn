#import "xmlvm.h"
#import <Foundation/Foundation.h>
#import "java_lang_String.h"



// NSURL
//----------------------------------------------------------------------------
typedef NSURL org_xmlvm_iphone_NSURL;
@interface NSURL (cat_NSURL)
- (void) __init_org_xmlvm_iphone_NSURL___java_lang_String: (java_lang_String*) url;
+ (NSURL*) URLWithString___java_lang_String: (java_lang_String*) url;
@end
