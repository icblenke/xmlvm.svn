
#include "org_xmlvm_iphone_UISwitch.h"

// UISwitch
//----------------------------------------------------------------------------
@implementation UISwitch (cat_org_xmlvm_iphone_UISwitch)

- (void) __init_org_xmlvm_iphone_UISwitch
{
    [self initWithFrame: CGRectZero];
}

- (void) __init_org_xmlvm_iphone_UISwitch___org_xmlvm_iphone_CGRect: (org_xmlvm_iphone_CGRect*) r
{
    CGRect rect = [r getCGRect];
    [self initWithFrame: rect];
}

- (void) setOn___boolean: (int) on
{
	[self setOn: on];
}
@end
