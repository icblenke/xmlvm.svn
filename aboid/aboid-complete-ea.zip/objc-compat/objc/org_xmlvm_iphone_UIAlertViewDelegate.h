#import "xmlvm.h"
#import "java_lang_Object.h"


@class org_xmlvm_iphone_UIAlertView;


// UIAlertViewDelegate
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_UIAlertViewDelegate : java_lang_Object <UIAlertViewDelegate>

- (void) __init_org_xmlvm_iphone_UIAlertViewDelegate;
- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;
- (void) clickedButtonAtIndex___org_xmlvm_iphone_UIAlertView_int
            :(org_xmlvm_iphone_UIAlertView*) alertView
            :(int) buttonIndex;
@end

