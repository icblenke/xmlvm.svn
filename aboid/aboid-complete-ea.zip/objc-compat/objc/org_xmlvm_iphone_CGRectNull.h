#import "xmlvm.h"
#import "org_xmlvm_iphone_CGRect.h"


// CGRectNull
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_CGRectNull : org_xmlvm_iphone_CGRect

- (void) __init_org_xmlvm_iphone_CGRectNull;
- (CGRect) getCGRect;

@end
