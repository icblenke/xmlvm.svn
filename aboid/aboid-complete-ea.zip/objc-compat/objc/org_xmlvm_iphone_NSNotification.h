#import "xmlvm.h"
#import "java_lang_Object.h"

// NSNotification
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_NSNotification : java_lang_Object
@end
