#import "java_io_InputStream.h"

// java.io.InputStream
//----------------------------------------------------------------------------
@implementation java_io_InputStream;
@end

