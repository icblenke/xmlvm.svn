#import "java_lang_String.h"

typedef java_lang_String java_lang_StringBuilder;
