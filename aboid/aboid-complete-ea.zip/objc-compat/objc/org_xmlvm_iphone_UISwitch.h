
#include "xmlvm.h"
#include "org_xmlvm_iphone_CGRect.h"


// UISwitch
//----------------------------------------------------------------------------
typedef UISwitch org_xmlvm_iphone_UISwitch;
@interface UISwitch (cat_org_xmlvm_iphone_UISwitch)
- (void) __init_org_xmlvm_iphone_UISwitch;
- (void) __init_org_xmlvm_iphone_UISwitch___org_xmlvm_iphone_CGRect: (org_xmlvm_iphone_CGRect*) rect;
- (void) setOn___boolean: (int) on;
@end

