#import "xmlvm.h"


// java.util.HashMap
//----------------------------------------------------------------------------
typedef NSMutableDictionary java_util_HashMap;
@interface NSMutableDictionary (cat_java_util_HashMap)

- (void) __init_java_util_HashMap;

@end