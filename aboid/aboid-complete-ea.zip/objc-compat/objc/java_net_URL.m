#import "java_net_URL.h"

// java.net.URL
//----------------------------------------------------------------------------
@implementation java_net_URL;
@end

