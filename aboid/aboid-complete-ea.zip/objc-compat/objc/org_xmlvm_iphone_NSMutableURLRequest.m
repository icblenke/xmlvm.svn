
#import "org_xmlvm_iphone_NSMutableURLRequest.h"


// NSMutableURLRequest
//----------------------------------------------------------------------------
@implementation NSMutableURLRequest (cat_NSMutableURLRequest)
- (void) __init_org_xmlvm_iphone_NSMutableURLRequest___org_xmlvm_iphone_NSURL: (org_xmlvm_iphone_NSURL*) url
{
    [self initWithURL: url];
}
@end
