#import "xmlvm.h"


// NSError
//----------------------------------------------------------------------------
typedef NSError org_xmlvm_iphone_NSError;
