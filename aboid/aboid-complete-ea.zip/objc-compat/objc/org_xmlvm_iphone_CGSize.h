#import "xmlvm.h"
#import "java_lang_Object.h"


// CGSize
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_CGSize : java_lang_Object {
@public float width;
@public float height;
}
@end