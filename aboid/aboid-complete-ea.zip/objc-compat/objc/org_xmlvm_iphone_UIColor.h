#import "xmlvm.h"


// UIColor
//----------------------------------------------------------------------------
typedef UIColor org_xmlvm_iphone_UIColor;
