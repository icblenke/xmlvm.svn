
#import "java_lang_Throwable.h"

// java.lang.Throwable
//----------------------------------------------------------------------------
@implementation java_lang_Throwable

- (id) init
{
    return [self initWithName: @"java_lang_Throwable" reason: nil userInfo: nil];
}

- (void) __init_java_lang_Throwable
{
    // Do nothing
}

- (NSString *) getMessage
{
    return [self reason];
}

- (NSString *) toString
{
    return [self name];
}

@end
