
#import "org_xmlvm_iphone_NSErrorHolder.h"


// NSErrorHolder
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_NSErrorHolder;
- (void) __init_org_xmlvm_iphone_NSErrorHolder
{
    [self init];
}
@end
