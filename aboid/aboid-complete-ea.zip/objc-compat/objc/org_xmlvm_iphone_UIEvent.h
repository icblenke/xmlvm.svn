#import "xmlvm.h"



// UIEvent
//----------------------------------------------------------------------------
typedef UIEvent org_xmlvm_iphone_UIEvent;
@interface UIEvent (cat_org_xmlvm_iphone_UIEvent)

@end