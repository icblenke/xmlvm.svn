#import "xmlvm.h"
#import "java_lang_Object.h"

@interface java_io_InputStream : java_lang_Object 
@end
