#import "xmlvm.h"
#import "java_lang_Object.h"


// NSErrorHolder
//----------------------------------------------------------------------------
@interface org_xmlvm_iphone_NSErrorHolder : java_lang_Object
- (void) __init_org_xmlvm_iphone_NSErrorHolder;
@end
