#import "org_xmlvm_iphone_CGPoint.h"

// CGPoint
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_CGPoint;
@end