#import "org_xmlvm_iphone_CGRectNull.h"


// CGRectNull
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_CGRectNull : org_xmlvm_iphone_CGRect

- (void) __init_org_xmlvm_iphone_CGRectNull
{
}

- (CGRect) getCGRect
{
	return CGRectNull;
}

@end
