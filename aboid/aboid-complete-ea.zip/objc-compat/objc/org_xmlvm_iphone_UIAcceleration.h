#import "xmlvm.h"


typedef UIAcceleration org_xmlvm_iphone_UIAcceleration;
