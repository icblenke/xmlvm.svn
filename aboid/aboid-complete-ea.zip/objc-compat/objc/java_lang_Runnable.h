#import "xmlvm.h"
#import "java_lang_Object.h"

@protocol java_lang_Runnable
- (void) run;
@end
