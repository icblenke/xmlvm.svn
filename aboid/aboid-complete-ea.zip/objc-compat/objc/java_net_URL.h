#import "xmlvm.h"
#import "java_lang_Object.h"

@interface java_net_URL : java_lang_Object 
@end
