#import "xmlvm.h"
#import <Foundation/Foundation.h>
#import "org_xmlvm_iphone_NSURL.h"



// NSMutableURLRequest
//----------------------------------------------------------------------------
typedef NSMutableURLRequest org_xmlvm_iphone_NSMutableURLRequest;
@interface NSMutableURLRequest (cat_NSMutableURLRequest)
- (void) __init_org_xmlvm_iphone_NSMutableURLRequest___org_xmlvm_iphone_NSURL: (org_xmlvm_iphone_NSURL*) url;
@end
