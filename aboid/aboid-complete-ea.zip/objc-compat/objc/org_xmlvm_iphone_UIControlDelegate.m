#import "org_xmlvm_iphone_UIControlDelegate.h"


// UIControlDelegate
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_UIControlDelegate
- (id) init
{
	[super init];
	return self;
}

- (void) __init_org_xmlvm_iphone_UIControlDelegate
{
}

@end
