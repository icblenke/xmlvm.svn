
#import "java_io_IOException.h"

// java.io.IOException
//----------------------------------------------------------------------------
@implementation java_io_IOException

- (id) init
{
    return [self initWithName: @"java_io_IOException" reason: nil userInfo: nil];
}

- (void) __init_java_io_Exception
{
    // Do nothing
}


@end
