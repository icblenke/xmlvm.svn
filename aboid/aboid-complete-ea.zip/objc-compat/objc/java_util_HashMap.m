#import "java_util_HashMap.h"


// java.util.HashMap
//----------------------------------------------------------------------------
@implementation NSMutableDictionary (cat_java_util_HashMap)

- (void) __init_java_util_HashMap
{
}

@end