
#import "java_lang_Exception.h"

// java.lang.Exception
//----------------------------------------------------------------------------
@implementation java_lang_Exception

- (id) init
{
    return [self initWithName: @"java_lang_Exception" reason: nil userInfo: nil];
}

- (void) __init_java_lang_Exception
{
    // Do nothing
}


@end
