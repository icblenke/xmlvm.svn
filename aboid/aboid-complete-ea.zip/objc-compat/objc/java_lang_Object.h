#import "xmlvm.h"

@class java_lang_Class;


typedef NSObject java_lang_Object;

@interface NSObject (cat_java_lang_Object) 
- (void) __init_java_lang_Object;
- (java_lang_Class*) getClass;
- (int) intValue;
@end