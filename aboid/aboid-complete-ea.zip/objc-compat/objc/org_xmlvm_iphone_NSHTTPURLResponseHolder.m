
#import "org_xmlvm_iphone_NSHTTPURLResponseHolder.h"


// NSHTTPURLResponseHolder
//----------------------------------------------------------------------------
@implementation org_xmlvm_iphone_NSHTTPURLResponseHolder;
- (void) __init_org_xmlvm_iphone_NSHTTPURLResponseHolder
{
    [self init];
}
@end
