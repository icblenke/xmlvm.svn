
#import "xmlvm.h"

@class org_xmlvm_iphone_UIAccelerometer;
@class org_xmlvm_iphone_UIAcceleration;


@protocol org_xmlvm_iphone_UIAccelerometerDelegate

- (void) accelerometerDidAccelerate___org_xmlvm_iphone_UIAccelerometer_org_xmlvm_iphone_UIAcceleration
             : (org_xmlvm_iphone_UIAccelerometer*) accelerometer
             : (org_xmlvm_iphone_UIAcceleration*) acceleration;

@end
