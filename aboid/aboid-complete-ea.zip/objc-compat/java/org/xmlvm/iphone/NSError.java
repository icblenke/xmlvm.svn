package org.xmlvm.iphone;


public class NSError
{

}
