package org.xmlvm.iphone;

abstract public class UIAlertViewDelegate {

    abstract public void clickedButtonAtIndex(UIAlertView alertView, int buttonIndex);
}
