package org.xmlvm.iphone;

public class NSIndexPath {

	private int section;
	private int row;

	public int getSection() {
		return section;
	}

	public int getRow() {
		return row;
	}

	public void setSection(int section) {
		this.section = section;
	}

	public void setRow(int row) {
		this.row = row;
	}

}
