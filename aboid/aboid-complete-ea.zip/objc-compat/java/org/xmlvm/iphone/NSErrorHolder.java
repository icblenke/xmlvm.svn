package org.xmlvm.iphone;


public class NSErrorHolder
{

}
