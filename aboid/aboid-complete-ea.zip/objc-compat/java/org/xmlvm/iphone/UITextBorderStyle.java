package org.xmlvm.iphone;

public class UITextBorderStyle {
	public static final int UITextBorderStyleNone = 0;
	public static final int UITextBorderStyleLine = 1;
	public static final int UITextBorderStyleBezel = 2;
	public static final int UITextBorderStyleRoundedRect = 3;
}
