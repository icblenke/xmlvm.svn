package org.xmlvm.iphone;


public class NSHTTPURLResponseHolder
{

}
