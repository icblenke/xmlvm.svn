
package org.xmlvm.iphone.internal;



public interface GestureListener
{

    public void gestureDragged(int dx, int dy);
    public void mouseClicked(int x, int y);
}
