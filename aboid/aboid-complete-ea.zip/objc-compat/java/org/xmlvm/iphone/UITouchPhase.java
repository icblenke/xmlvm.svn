package org.xmlvm.iphone;

public class UITouchPhase {
    public static final int UITouchPhaseBegan      = 0;
    public static final int UITouchPhaseMoved      = 1;
    public static final int UITouchPhaseStationary = 2;
    public static final int UITouchPhaseEnded      = 3;
    public static final int UITouchPhaseCancelled  = 4;
}
