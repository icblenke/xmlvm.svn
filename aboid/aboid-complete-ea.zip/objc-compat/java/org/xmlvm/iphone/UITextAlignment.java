package org.xmlvm.iphone;

public class UITextAlignment {
	public static final int UITextAlignmentLeft = 0;
	public static final int UITextAlignmentCenter = 1;
	public static final int UITextAlignmentRight = 2;
}
