package org.xmlvm.iphone;

public interface UIAccelerometerDelegate {
	void accelerometerDidAccelerate(UIAccelerometer accelerometer, UIAcceleration acceleration);
}
