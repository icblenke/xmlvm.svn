package org.xmlvm.iphone;

public class CGRectNull extends CGRect {

	public CGRectNull() {
		super(-1, -1, -1, -1);
	}

}
