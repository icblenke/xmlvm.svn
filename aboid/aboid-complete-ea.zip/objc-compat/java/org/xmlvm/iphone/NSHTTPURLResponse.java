package org.xmlvm.iphone;


public class NSHTTPURLResponse
{

}
