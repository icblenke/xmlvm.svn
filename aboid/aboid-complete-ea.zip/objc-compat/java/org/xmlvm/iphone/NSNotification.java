package org.xmlvm.iphone;


public class NSNotification
{

}
