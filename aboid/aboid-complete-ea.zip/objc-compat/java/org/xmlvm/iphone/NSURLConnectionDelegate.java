package org.xmlvm.iphone;

public class NSURLConnectionDelegate {
    public void connectionDidFinishLoading(NSURLConnection connection) {
        // Do nothing
    }

    public void connectionDidFailWithError(NSURLConnection connection, NSError error) {
        // Do nothing
    }
}
