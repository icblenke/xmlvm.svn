package org.xmlvm.iphone;

public class UITableViewStyle {
	public static final int UITableViewStylePlain = 0;
	public static final int UITableViewStyleGrouped = 1;
}
