package org.xmlvm.iphone;

abstract public class UITableViewDelegate {

	abstract public float heightForRowAtIndexPath(UITableView tableView,
			NSIndexPath indexPath);
}
