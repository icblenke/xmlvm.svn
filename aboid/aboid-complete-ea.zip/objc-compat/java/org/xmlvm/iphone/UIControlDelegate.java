package org.xmlvm.iphone;

public abstract class UIControlDelegate {

    public abstract void raiseEvent();
}
