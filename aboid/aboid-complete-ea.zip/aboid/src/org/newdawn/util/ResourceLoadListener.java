package org.newdawn.util;

public interface ResourceLoadListener {

	public void chunkLoaded();
}
